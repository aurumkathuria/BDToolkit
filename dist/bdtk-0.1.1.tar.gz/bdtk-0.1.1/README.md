# BDTK

pip install bdtk

The Big Data Analysis Toolkit. 

Author: Aurum Kathuria 
(LinkedIn: https://linkedin.com/in/heyaurum, GitHub: https://github.com/aurumkathuria)

This is a toolkit designed to optimize data anlysis for data scientists & data analysts. It includes features ranging from data type optimization to interactive multivariate distribution visualizations, with more to come as well!

If you have any feature requests, feel free to open an issue asking for it, or shoot me a message on my LinkedIn (linked above)!

I'd also love feedback, whether that's on my code, my approach, or just telling me that I'm an idiot (true) - again, hit me on LinkedIn or open an issue here, I'll be active on both platforms.

I hope this helps you with your data exploration & analysis! Take care & stay safe!
